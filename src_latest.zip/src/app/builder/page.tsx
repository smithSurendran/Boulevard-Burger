import BurgerBuilder from '@/components/BurgerBuilder'
export default function BuilderPage() {
  return <BurgerBuilder />
}
